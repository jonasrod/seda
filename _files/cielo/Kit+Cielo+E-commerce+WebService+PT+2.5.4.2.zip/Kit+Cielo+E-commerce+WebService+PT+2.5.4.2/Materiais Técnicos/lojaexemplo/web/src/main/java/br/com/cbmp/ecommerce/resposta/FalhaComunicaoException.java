package br.com.cbmp.ecommerce.resposta;


public class FalhaComunicaoException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public FalhaComunicaoException(String erro) {
		super(erro);
	}

	
	

}
