package br.com.cbmp.ecommerce.requisicao;

public enum Operacao {
	
	AUTORIZACAO,
	CAPTURA,
	CANCELAMENTO,
	CONSULTA,
	CONSULTA_CH_SEC;
}
